#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HASH_SIZE 100

// Şarkı yapısı - Doubly Linked List
typedef struct Song {
//Şarkı adı ve sanatçıyı tutar.
    char name[100];
    char artist[100];
//Çift yönlü bağlı liste için gerekli adresler.
    struct Song* next;
    struct Song* prev;
} Song;

// Playlist yapısı -Binary Search Tree düğümü
// Şarkılar burada bir linked list haline getirilir ve sonra BST düğümü olarak atanır.
typedef struct PlaylistNode {
//Oynatma listesi adı
    char name[100];
//Bu listeye bağlı ilk şarkıyı işaret eder, doubly linked listin başı.
//Ve yukardaki Song Struct yapısı kullanılarak linked list oluşturulur.
    Song* head;
// Binary search treenin sol ve sağ dalları
    struct PlaylistNode* left;
    struct PlaylistNode* right;
} PlaylistNode;

// Rating için ek yapı
typedef struct SongRating {
    char name[100];
    char artist[100];
    int rating;
    struct SongRating* next;
// bir sonraki puanlama elemanına referans.
} SongRating;

// Kodda kullanılacak genel değişkenler
PlaylistNode* playlistRoot = NULL;
// Doubly linked listin kök düğümünün referansını tutar
PlaylistNode* allSongsPlaylist = NULL;
//Tüm şarkıların saklandığı özel bir oynatma listesinin referansını tutar.
PlaylistNode* currentPlaylist = NULL;
//Kullanıcı tarafından seçilen ve aktif olarak kullanılan oynatma listesinin referansını tutar.
SongRating* ratingHashTable[HASH_SIZE] = {NULL};
//Şarkılara verilen puanları saklamak için bir hash tablosudur. Her bir indeks, bir bağlı liste başı olabilir.


// Hash tablosu için indeks üretme fonksiyonu:
//daha geniş bir integer aralığı için unsigned int kullandık.

//Amacı, şarkıların hash tablosunda yerleşmesi gereken yerin indeksini üretmek.
//Başlangıçta hash değeri sıfır olarak başlar.
//Stringdeki her karakter için, hash değeri 31 ile çarpılır ve karakterin ASCII değeri eklenir.
//Döngü sonunda, hash değeri HASH_SIZE'a göre mod alınarak, tabloda geçerli bir indeks üretilir.
unsigned int hash(char* str) {
    unsigned int hash = 0;
    for(int i = 0; str[i] != '\0'; i++) {
        hash = 31 * hash + str[i];
    }
    return hash % HASH_SIZE;
}

// Rating ekleme fonksiyonu:
// amacı bir şarkıya puan eklemek veya mevcut bir şarkının puanını güncellemektir
//Şarkının adı hash fonksiyonu ile bir indeks oluşturur.
//Hash tablosunun ilgili indeksinde şarkı zaten varsa, puan güncellenir.
//Şarkı bulunamazsa, yeni bir SongRating düğümü oluşturulur ve hash tablosuna eklenir.
void addRating(char* artist, char* name, int rating) {
    unsigned int index = hash(name);

    // Önce aynı şarkı için var olan rating'i bul
    SongRating* current = ratingHashTable[index];
    while (current != NULL) {
        // Aynı şarkı için rating varsa güncelle
        if (strcmp(current->name, name) == 0 && strcmp(current->artist, artist) == 0) {
            current->rating = rating;
            printf("%s - %s şarkısının puanı %d olarak güncellendi.\n", artist, name, rating);
            return;
        }
        current = current->next;
    }

    // Eğer daha önce rating yoksa yeni rating ekle
    SongRating* newRating = (SongRating*)malloc(sizeof(SongRating));
    strcpy(newRating->name, name);
    strcpy(newRating->artist, artist);
    newRating->rating = rating;
    newRating->next = ratingHashTable[index];
    ratingHashTable[index] = newRating;

    printf("%s - %s şarkısına %d puan verildi.\n", artist, name, rating);
}

// Rating listesi
// Amacı şarkıları puanlarına göre azalan sırada listelemek.
// Tüm hash tablosu taranır ve tüm SongRating düğümleri bir diziye alınır.
// Bu dizideki elemanlar düzenli bir şekilde sıralanır.
// Sıralama tamamlandıktan sonra, her bir şarkı puanı ekrana yazdırılır.

void listRatedSongs() {
    SongRating* allRatings[HASH_SIZE * 10];
    int ratingCount = 0;

    for(int i = 0; i < HASH_SIZE; i++) {
        SongRating* current = ratingHashTable[i];
        while(current != NULL) {
            allRatings[ratingCount++] = current;
            current = current->next;
        }
    }

    for(int i = 0; i < ratingCount - 1; i++) {
        for(int j = 0; j < ratingCount - i - 1; j++) {
            if(allRatings[j]->rating < allRatings[j+1]->rating) {
                SongRating* temp = allRatings[j];
                allRatings[j] = allRatings[j+1];
                allRatings[j+1] = temp;
            }
        }
    }

    printf("Şarkılar Puanlarına Göre Sıralandı:\n");
    for(int i = 0; i < ratingCount; i++) {
        printf("%s - %s: %d Puan\n",
               allRatings[i]->artist,
               allRatings[i]->name,
               allRatings[i]->rating);
    }
}

//Eğer liste boşsa, işlem yapılmaz.
//Eğer listede yalnızca bir şarkı varsa, şarkı silinir ve head NULL yapılır.
//Daha fazla şarkı varsa, mevcut şarkı silinir ve listenin bağlantıları güncellenir.
void deleteCurrentSong(PlaylistNode* playlist) {
    if (playlist->head == NULL) {
        printf("Oynatma listesi boş. Silinecek şarkı yok.\n");
        return;
    }

    Song* current = playlist->head;

    if (current->next == current) { // Tek bir şarkı varsa
        free(current);
        playlist->head = NULL;
    } else {
        Song* prev = current->prev;
        Song* next = current->next;
        prev->next = next;
        next->prev = prev;
        playlist->head = next; // Sonraki şarkıyı baş yap
        free(current);
    }

    printf("Şarkı silindi.\n");
}
//Yeni bir şarkı düğümü oluşturur.
//Bellekten yeni bir Song düğümü için yer ayrılır.
//Şarkı adı ve sanatçı adı kopyalanır.
//next ve prev NULL olarak başlatılır.
Song* createSong(char* name, char* artist) {
    Song* newSong = (Song*)malloc(sizeof(Song));
    strcpy(newSong->name, name);
    strcpy(newSong->artist, artist);
    newSong->next = NULL;
    newSong->prev = NULL;
    return newSong;
}
//Şarkıyı oynatma listesine ekler.
//Yeni bir şarkı düğümü oluşturulur,createSong fonksiyonu kullanarak.
//Eğer liste boşsa, yeni şarkı liste başı olur ve kendisini işaret eder, dairesel bağlı liste kullANIMI.
//Eğer listede zaten şarkılar varsa, yeni şarkı listenin sonuna eklenir ve bağlantılar güncellenir yani tail düğümü güncellenir.
void addSongToPlaylist(PlaylistNode* playlist, char* artist, char* name) {
    Song* newSong = createSong(name, artist);
    if (playlist->head == NULL) {
        playlist->head = newSong;
        newSong->next = newSong;
        newSong->prev = newSong;
    } else {
        Song* tail = playlist->head->prev;
        tail->next = newSong;
        newSong->prev = tail;
        newSong->next = playlist->head;
        playlist->head->prev = newSong;
    }

    printf("%s - %s %s oynatma listesine eklendi.\n", artist, name, playlist->name);
}
//Yeni bir oynatma listesini ikili arama ağacına ekler.
//Eğer ağaçta hiç düğüm yoksa, yeni düğüm oluşturulup geri döndürülür.
//Eğer bir düğüm varsa, strcmp kullanılarak yeni liste adı ile mevcut düğüm adı karşılaştırılır:
//Yeni isim alfabetik olarak küçükse, sol alt düğüme eklenir.
//Büyükse, sağ alt düğüme eklenir.
//Eğer aynı isimde bir liste varsa, işlem yapılmaz ve düğüm geri döndürülür.
PlaylistNode* insertPlaylist(PlaylistNode* node, char* name) {
    if (node == NULL) {
        PlaylistNode* newNode = (PlaylistNode*)malloc(sizeof(PlaylistNode));
        strcpy(newNode->name, name);
        newNode->head = NULL;
        newNode->left = newNode->right = NULL;
        return newNode;
    }

    int compareResult = strcmp(name, node->name);
    if (compareResult < 0)
        node->left = insertPlaylist(node->left, name);
    else if (compareResult > 0)
        node->right = insertPlaylist(node->right, name);
    else
        return node;

    return node;
}

//Oynatma listelerini sıralı bir şekilde, inorder şekilde ekrana yazdırır.
//listPlaylistsInorder fonksiyonu bir düğümü ziyaret etmeden önce sol alt düğüm, sonra kendisi ve ardından sağ alt düğümü ziyaret eder.
//Her düğüm için bir numaralandırma yapılır,counter kullanılarak.
//listPlaylists fonksiyonu, ağacın kökünden başlayarak listeleme işlemine başlar.
void listPlaylistsInorder(PlaylistNode* node, int* counter) {
    if (node == NULL) return;

    listPlaylistsInorder(node->left, counter);
    printf("%d- %s\n", (*counter)++, node->name);
    listPlaylistsInorder(node->right, counter);
}

void listPlaylists() {
    if (playlistRoot == NULL) {
        printf("Henüz hiçbir oynatma listesi oluşturulmamış.\n");
        return;
    }
    printf("Oynatma Listeleri:\n");
    int counter = 1;
    listPlaylistsInorder(playlistRoot, &counter);
}

//Kullanıcıdan alınan bir oynatma listesi numarasına göre, alfabetik sıralı bir PlaylistNode düğümünü döndürür.
//Eğer sol alt düğümden bir sonuç dönerse yani leftResulttan, bu sonuç hemen geri döndürülür.
//current sayacı artırılarak mevcut düğümün hedef düğüm olup olmadığı kontrol edilir.
//Eğer hedef bulunmazsa, sağ alt düğüme geçiş yapılır.
// Inorder dolaşma yöntemi kullanılarak, hedef numaraya karşılık gelen düğüm döndürülür.

PlaylistNode* searchPlaylistByNumber(PlaylistNode* node, int* current, int target) {
    if (node == NULL) return NULL;

    PlaylistNode* leftResult = searchPlaylistByNumber(node->left, current, target);
    if (leftResult != NULL) return leftResult;

    if (*current == target) return node;
    (*current)++;

    return searchPlaylistByNumber(node->right, current, target);
}

//Kullanıcıdan bir oynatma listesi seçmesini ister ve bu listeyi PlaylistNode olarak döndürür.
//Oynatma listeleri listelenir, listPlaylists fonksiyonu ile.
//Kullanıcıdan bir liste numarası istenir.
//searchPlaylistByNumber fonksiyonu kullanılarak, seçilen liste düğümü bulunur ve döndürülür.

PlaylistNode* selectPlaylistExcludingAllSongs() {
    if (playlistRoot == NULL) {
        printf("Henüz hiçbir oynatma listesi oluşturulmamış.\n");
        return NULL;
    }

    listPlaylists();
    printf("Bir oynatma listesi numarası girin: ");
    int choice;
    scanf("%d", &choice);

    int current = 1;
    PlaylistNode* selectedPlaylist = searchPlaylistByNumber(playlistRoot, &current, choice);

    if (selectedPlaylist == NULL) {
        printf("Oynatma listesi bulunamadı.\n");
    }

    return selectedPlaylist;
}
//Kullanıcıdan bir oynatma listesi seçmesini isteyen ve seçilen listeyi bir PlaylistNode işaretçisi olarak döndürür
//Kullanıcıdan oynatma listesi numarasını alır.
//Bu numaraya karşılık gelen PlaylistNode düğümünü bulur.
//Bulunan düğümü döndürür, eğer bir liste bulunamazsa NULL döner.

PlaylistNode* selectPlaylist() {
    if (playlistRoot == NULL) {
        printf("Henüz hiçbir oynatma listesi oluşturulmamış.\n");
        return NULL;
    }

    listPlaylists();
    printf("Bir oynatma listesi numarası girin: ");
    int choice;
    scanf("%d", &choice);

    int current = 1;
    PlaylistNode* selectedPlaylist = searchPlaylistByNumber(playlistRoot, &current, choice);

    if (selectedPlaylist == NULL) {
        printf("Oynatma listesi bulunamadı.\n");
    }

    return selectedPlaylist;
}

//insertPlaylist fonksiyonu çağrılarak, yeni liste ağaca eklenir.
//Doğru bir şekilde ekleme yapıldığında, kullanıcıya bilgi mesajı gösterilir.
void addPlaylist(char* name) {
    playlistRoot = insertPlaylist(playlistRoot, name);
    printf("Yeni oynatma listesi oluşturuldu: %s\n", name);
}

//Verilen bir PlaylistNode'da şarkı veya sanatçı adına göre bir arama yapar ve bulunan sonuçları ekrana yazdırır.
void searchSong(PlaylistNode* playlist) {
    char searchTerm[100];
    printf("Aramak istediğiniz şarkı veya sanatçı adını girin: ");
    scanf("%s", searchTerm);

    Song* temp = playlist->head;
    int found = 0;
// Eğer oynatma listesi boşsa, fonksiyon sonlanır ve bir uyarı mesajı verir.
    if (temp == NULL) {
        printf("Oynatma listesi boş.\n");
        return;
    }

// Liste başından başlayarak, şarkı ve sanatçı adında arama teriminin geçip geçmediği kontrol edilir ,strstr fonksiyonu kullanılarak.
// Uygun eşleşmeler ekrana yazdırılır.
    do {
        if (strstr(temp->name, searchTerm) != NULL || strstr(temp->artist, searchTerm) != NULL) {
            printf("Bulunan Şarkı: %s - %s\n", temp->artist, temp->name);
            found = 1;
        }
        temp = temp->next;
    } while (temp != playlist->head);

    if (!found) {
        printf("Arama sonucu bulunamadı.\n");
    }
}

void showMenu() {
    // İlk açılışta Tüm Şarkılar playlistini başlat
    if (currentPlaylist == NULL) {
        currentPlaylist = allSongsPlaylist;
    }

    while (1) {
        printf("\n+------------------------------+\n");
        printf("|        Müzik Oynatıcı        |\n");
        printf("+------------------------------+\n");

        // Şu an çalan playlistin adını göster
        printf("| Aktif Playlist: %s\n", currentPlaylist->name);
        printf("|                              |\n");

        if (currentPlaylist->head) {
            printf("| Şarkı: %s\n", currentPlaylist->head->name);
            printf("| Sanatçı: %s\n", currentPlaylist->head->artist);
        } else {
            printf("| Şarkı: [Yok]                 |\n");
            printf("| Sanatçı: [Yok]               |\n");
        }

        printf("|                              |\n");
        printf("|       <<    [==]     >>      |\n");
        printf("|                              |\n");
        printf("|                              |\n");
        printf("|  [+] Daha Fazla              |\n");
        printf("|  [P] Oynatma Listesine Ekle  |\n");
        printf("|  [R] Şarkıya Puan Ver        |\n");
        printf("|  [D] Şarkıyı Sil             |\n");
        printf("|  [Q] Çıkış                   |\n");
        printf("|                              |\n");
        printf("+------------------------------+\n");
        printf("Seçiminizi yapın: ");

        char command;
        scanf(" %c", &command);

        switch (command) {
            case '>':
                if (currentPlaylist->head != NULL) {
                    currentPlaylist->head = currentPlaylist->head->next;
                }
                break;
            case '<':
                if (currentPlaylist->head != NULL) {
                    currentPlaylist->head = currentPlaylist->head->prev;
                }
                break;
            case 'D':
                deleteCurrentSong(currentPlaylist);
                break;
            case '+': {
                int choice;
                printf("\n[1] Şarkı Ekle\n");
                printf("[2] Oynatma Listelerini Görüntüle\n");
                printf("[3] Oynatma Listesi Oluştur\n");
                printf("[4] Şarkı Ara\n");
                printf("[5] Şarkıları Puanına Göre Listele\n");
                printf("[6] Oynatma Listesini Değiştir\n");
                printf("Seçiminiz: ");
                scanf("%d", &choice);
                if (choice == 1) {
                    char artist[100], name[100];
                    printf("Sanatçı adı: ");
                    scanf("%s", artist);
                    printf("Şarkı adı: ");
                    scanf("%s", name);
                    addSongToPlaylist(allSongsPlaylist, artist, name);
                } else if (choice == 2) {
                    PlaylistNode* playlist = selectPlaylist();
                    if (playlist) {
                        Song* temp = playlist->head;
                        if (temp == NULL) {
                            printf("Bu Oynatma Listesinde Şarkı Yok.\n");
                        } else {
                            printf("%s Oynatma Listesindeki Şarkılar:\n", playlist->name);
                            do {
                                printf("%s - %s\n", temp->artist, temp->name);
                                temp = temp->next;
                            } while (temp != playlist->head);
                        }
                    }
                } else if (choice == 3) {
                    char playlistName[100];
                    printf("Yeni Oynatma Listesinin Adı: ");
                    scanf("%s", playlistName);
                    addPlaylist(playlistName);
                } else if (choice == 4) {
                    searchSong(currentPlaylist);
                } else if (choice == 5) {
                    listRatedSongs();
                } else if (choice == 6) {
                    PlaylistNode* selectedPlaylist = selectPlaylist();
                    if (selectedPlaylist != NULL) {
                        currentPlaylist = selectedPlaylist;
                        printf("%s Oynatma Listesine Geçildi.\n", currentPlaylist->name);
                    }
                }
                break;
            }
            case 'P': {
                PlaylistNode* playlist = selectPlaylistExcludingAllSongs();
                if (playlist && strcmp(playlist->name, "Tüm Şarkılar") != 0 && currentPlaylist->head) {
                    addSongToPlaylist(playlist,
                        currentPlaylist->head->artist,
                        currentPlaylist->head->name);
                }
                break;
            }
            case 'R':
                if (currentPlaylist->head != NULL) {
                    int rating;
                    printf("Şarkıya 0-100 arasında puan verin: ");
                    scanf("%d", &rating);

                    if (rating >= 0 && rating <= 100) {
                        addRating(
                            currentPlaylist->head->artist,
                            currentPlaylist->head->name,
                            rating
                        );
                    } else {
                        printf("Lütfen 0-100 arasında bir puan girin.\n");
                    }
                }
                break;
            case 'Q':
                printf("Çıkış yapılıyor...\n");
                return;
            default:
                printf("Geçersiz komut.\n");
                break;
        }
    }
}

int main() {
    // Tüm Şarkılar playlistini otomatik olarak oluştur
    allSongsPlaylist = insertPlaylist(playlistRoot, "Tüm Şarkılar");
    playlistRoot = allSongsPlaylist;
    currentPlaylist = allSongsPlaylist;

    showMenu();
    return 0;
}

